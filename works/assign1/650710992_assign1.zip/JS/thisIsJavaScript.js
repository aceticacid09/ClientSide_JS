function nameFunc(){
    document.getElementById("name").innerHTML = "Prompoj Kongmankaittikun 650710992";
}

function colorFunc(){
    document.getElementById("color").innerHTML = "CORAL";
    document.getElementById("color").style.fontWeight = "bold";
    document.getElementById("color").style.color = "white";
    document.getElementById("color").style.backgroundColor ="#FF7F50";

}

function friendFunc(){
    document.getElementById("namef").innerHTML = "breeze, nine, mo, phu, phuripat";
}

function dateFunc(){
    document.getElementById("date").innerHTML = "3 พฤศจิกายน 2546";
}

function wordFunc(){
    document.getElementById("word").innerHTML = "นอนน้อยแต่นอนนะ";
}

function byeFunc(){
    document.write('<h2 style="text-align: center;">GOOD BYE</h2>');
}